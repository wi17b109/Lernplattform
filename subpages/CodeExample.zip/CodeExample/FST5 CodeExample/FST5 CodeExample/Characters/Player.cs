﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace FST5_CodeExample.Characters
{
    public class Player : BaseCharacter
    {
        public Player(int currentHitPoints, int maximumHitPoints, int level, int attack, int defense, string name) : base(currentHitPoints, maximumHitPoints, level, attack, defense, name)
        {
        }
    }
}
