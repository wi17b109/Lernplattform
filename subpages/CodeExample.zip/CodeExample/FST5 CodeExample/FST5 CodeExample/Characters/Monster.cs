﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FST5_CodeExample.Characters
{
    public class Monster : BaseCharacter
    {
        public Monster(int currentHitPoints, int maximumHitPoints, int level, int attack, int defense, string name) : base(currentHitPoints, maximumHitPoints, level, attack, defense, name)
        {
        }
    }
}
