﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FST5_CodeExample.Characters
{
    public class BaseCharacter : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private int currentHitPoints;

        public int CurrentHitPoints
        {
            get { return currentHitPoints; }
            set
            {
                currentHitPoints = value;
                OnPropertyChanged();
            }
        }

        // public int CurrentHitPoints { get; set; }
        public int MaximumHitPoints { get; set; }
        public int Level { get; set; }

        public int Attack { get; set; }
        public int Defense { get; set; }
        public string Name { get; set; }


        public BaseCharacter(int currentHitPoints, int maximumHitPoints, int level, int attack, int defense, string name)
        {
            CurrentHitPoints = currentHitPoints;
            MaximumHitPoints = maximumHitPoints;
            Level = level;
            Attack = attack;
            Defense = defense;
            Name = name;
        }
    }
}