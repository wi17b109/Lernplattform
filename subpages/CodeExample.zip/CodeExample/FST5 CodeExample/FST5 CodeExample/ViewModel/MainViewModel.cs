using System;
using System.ComponentModel;
using System.Windows;
using FST5_CodeExample.Characters;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.CommandWpf;

namespace FST5_CodeExample.ViewModel
{

    public class MainViewModel : ViewModelBase
    {
        public int attack { get; set; }
        public int defence { get; set; }
        public int currentHitPoints { get; set; }
        private Player player;
        public int dmg { get; set; }
        public int roundCounter { get; set; }

        public Monster[] monsters = new Monster[5];
        public RelayCommand BtnPlayerNameClicked { get; set; }
        public RelayCommand BtnGoClicked { get; set; }
        private string currName;

        public string CurrName
        {
            get { return currName; }
            set { currName = value;  }
        }

        private Monster currentMonster;

        public Monster curMonster
        {
            get { return currentMonster; }
            set { currentMonster = value; RaisePropertyChanged("curMonster"); }
        }

        public Player Player
        {
            get { return player; }
            set { player = value; RaisePropertyChanged("Player"); }
        }

        private int counter;

        public int Counter
        {
            get { return counter; }
            set { counter = value; }
        }

        private string message;

        public string MyMessage
        {
            get { return message; }
            set { message = value; }
        }



        public MainViewModel()
        {
            player = new Player(10, 10, 1, 2, 1, "Player");
            int a = 0;
            for (int i = 1; i <= 5; i++)
            {
                monsters[a] = new Monster(10 + i, 10 + i, i, i + 1, i, "Monster" + i);
                a++;
            }

            BtnPlayerNameClicked = new RelayCommand(() =>
            {
                player.Name = currName;
                RaisePropertyChanged("Player");
            });
            BtnGoClicked = new RelayCommand(() =>
            {
                battle();
            });

            curMonster = findMonster();
            MyMessage = "";
        }

        private void battle()
        {
            int hp;
            bool deadMonster = false;
            bool deadPlayer = false;
            switch (roundCounter % 2)
            {
                case 0:
                    hp = hitpointsBerechnen(player.Attack, curMonster.Defense, curMonster.CurrentHitPoints);
                    curMonster.CurrentHitPoints = hp;
                    deadMonster = checkHitPoints(hp);
                    Ticker();
                    roundCounter++;
                    break;
                case 1:
                    hp = hitpointsBerechnen(curMonster.Attack, player.Defense, player.CurrentHitPoints);
                    player.CurrentHitPoints = hp;
                    deadPlayer = checkHitPoints(hp);
                    Ticker();
                    roundCounter++;
                    break;
            }
            if (deadMonster)
            {
                LevelUp();
                if (currentMonster.Level != 5)
                {
                    curMonster = findMonster();
                }

                counter++;
                roundCounter = 0;
                MyMessage = "";
                MyMessage = "You killed the monster!\n";
                if (currentMonster.Level == 5)
                {
                    MessageBox.Show(player.Name + " killed the last enemy while he was crying like a bitch!", "Game Status", MessageBoxButton.OK);
                }
            }
            if (deadPlayer)
            {
                MessageBox.Show(player.Name + " killed " + counter + " enemies before crying like a bitch!", "Game Status", MessageBoxButton.OK);
                Player.CurrentHitPoints = Player.MaximumHitPoints;
                counter = 0;
                MyMessage = "";
                MyMessage = "The monster killed you!\n";
            }
        }

        private void Ticker()
        {
            string cur = "";
            if(dmg > 1)
            {
                cur = "BAM OIDA!\n";
            }
            if (roundCounter % 2 == 0)
            {
                cur += "You hit the monster for " + dmg + " Damage\n";
            }
            else
            {
                cur += "The monster hit you for " + dmg + " Damage\n";
            }
            cur += MyMessage;
            RaisePropertyChanged("MyMessage");
            MyMessage = cur;
        }

        private bool checkHitPoints(int hp)
        {
            if (hp <= 0)
            {
                return true;
            }
            return false;
        }

        private Monster findMonster()
        {
            return monsters[player.Level - 1];

        }

        public int hitpointsBerechnen(int attack, int defence, int currentHitPoints)
        {
            if (attack > defence)
            {
                Random r = new Random();
                if ((r.Next(100) % 10) == 0) // change to random
                {
                    dmg = (2 * attack - defence);
                    return currentHitPoints - (2 * attack - defence);
                }
                dmg = (attack - defence);
                return currentHitPoints - (attack - defence);
            }
            else
            {
                dmg = 0;
                return currentHitPoints;
            }
        }

        public void LevelUp()
        {
            player.Attack = player.Attack + 1;
            player.Defense = player.Defense + 1;
            player.Level = player.Level + 1;

            player.MaximumHitPoints = player.MaximumHitPoints + 6;
            player.CurrentHitPoints = player.MaximumHitPoints;
            RaisePropertyChanged("Player");

        }
    }
}